/**
 * ╔══════════════════════════════════════════════════╗
 * ║              DOOM CLOCK — v2.0                   ║
 * ║          FoundryVTT V13 Module                   ║
 * ║                                                  ║
 * ║  Countdown clock with two hardcoded event tiers: ║
 * ║   • SIGNS     — when value drops into 1–N zone   ║
 * ║   • ENCOUNTER — when value hits 0 (auto-resets)  ║
 * ║                                                  ║
 * ║  Each tier posts to chat and/or draws a table.   ║
 * ║  Clock is draggable, resizable, sidebar-aware.   ║
 * ╚══════════════════════════════════════════════════╝
 */

const MODULE_ID = "doom-clock";
const S_CLOCKS  = "clocks";

// ──────────────────────────────────────────────────────
// Utilities
// ──────────────────────────────────────────────────────

const uid   = () => foundry.utils.randomID(12);
const isGM  = () => game.user.isGM;
const clamp = (v, lo, hi) => Math.min(Math.max(v, lo), hi);

// Returns true if the current user may interact with clock controls
const canControl = (clock) => isGM() || (clock.playerControl === true);

async function resolveTable(nameOrUuid) {
  if (!nameOrUuid?.trim()) return null;
  if (nameOrUuid.includes(".")) {
    try { const d = await fromUuid(nameOrUuid); if (d) return d; } catch (_) {}
  }
  return game.tables.getName(nameOrUuid.trim()) ?? null;
}

// ──────────────────────────────────────────────────────
// Settings + Keybindings
// ──────────────────────────────────────────────────────

Hooks.once("init", () => {

  game.settings.register(MODULE_ID, S_CLOCKS, {
    name:    "Doom Clocks Data",
    scope:   "world",
    config:  false,
    type:    Array,
    default: [],
    onChange: () => DoomClockPanel.instance?.render(),
  });

  game.keybindings.register(MODULE_ID, "togglePanel", {
    name:     "Toggle Doom Clock Panel",
    hint:     "Show / hide all Doom Clock widgets  (Alt + D)",
    editable: [{ key: "KeyD", modifiers: ["Alt"] }],
    onDown: () => {
      const p = document.getElementById("doom-clock-panel");
      if (p) p.style.display = p.style.display === "none" ? "" : "none";
    },
  });

});

// ──────────────────────────────────────────────────────
// Clock data schema (stored in world settings)
// ──────────────────────────────────────────────────────
//
//  id                  : string
//  name                : string
//  max                 : number   (default 20)
//  value               : number   (starts at max, counts down)
//  dice                : "d6"|"d8"|"d12"
//  size                : number   (SVG pixel size, default 110)
//  position            : {x,y}|null
//
//  signsThresholdMax   : number   (top of danger zone, default 5)
//  signsChat           : bool
//  signsMessage        : string
//  signsTable          : string   (name or UUID, optional)
//
//  encounterChat       : bool
//  encounterMessage    : string
//  encounterTable      : string
//
//  playerControl       : bool     (if true, players can also roll/tick/reset)
//  signsHasFired       : bool     (reset when clock resets)

// ──────────────────────────────────────────────────────
// ClockDB  — simple CRUD around world settings
// ──────────────────────────────────────────────────────

const ClockDB = {

  getAll() { return game.settings.get(MODULE_ID, S_CLOCKS) ?? []; },

  async _save(clocks) { await game.settings.set(MODULE_ID, S_CLOCKS, clocks); },

  async add(data) {
    const clocks = this.getAll();
    const max    = Number(data.max) || 20;
    clocks.push({
      id:    uid(),
      name:  data.name ?? "Encounter Clock",
      max,
      value: max,
      dice:  data.dice ?? "d6",
      size:  110,
      position: null,
      signsThresholdMax: Number(data.signsThresholdMax) || 5,
      signsChat:    data.signsChat    ?? true,
      signsMessage: data.signsMessage ?? "⚠️ Something stirs… the party notices signs of danger.",
      signsTable:   data.signsTable   ?? "",
      encounterChat:    data.encounterChat    ?? true,
      encounterMessage: data.encounterMessage ?? "💀 A random encounter occurs!",
      encounterTable:   data.encounterTable   ?? "",
      playerControl: data.playerControl ?? false,
      signsHasFired: false,
    });
    await this._save(clocks);
  },

  async update(id, changes) {
    const clocks = this.getAll();
    const i = clocks.findIndex(c => c.id === id);
    if (i === -1) return null;
    clocks[i] = foundry.utils.mergeObject(clocks[i], changes, { inplace: false });
    await this._save(clocks);
    return clocks[i];
  },

  async remove(id) { await this._save(this.getAll().filter(c => c.id !== id)); },

  getById(id) { return this.getAll().find(c => c.id === id) ?? null; },
};

// ──────────────────────────────────────────────────────
// Event Engine
// ──────────────────────────────────────────────────────

const EventEngine = {

  async evaluate(clock, prevValue) {
    const cur      = clock.value;
    const signsTop = clock.signsThresholdMax ?? 5;

    // SIGNS — fires first time value drops INTO zone 1…signsTop
    if (!clock.signsHasFired && cur > 0 && cur <= signsTop && prevValue > signsTop) {
      await ClockDB.update(clock.id, { signsHasFired: true });
      await this._fire(clock, "signs");
    }

    // ENCOUNTER — fires when value hits 0, then auto-resets
    if (cur <= 0 && prevValue > 0) {
      await this._fire(clock, "encounter");
      await ClockDB.update(clock.id, { value: clock.max, signsHasFired: false });
      setTimeout(() => DoomClockPanel.instance?.render(), 80);
    }
  },

  async _fire(clock, type) {
    const isSigns  = type === "signs";
    const label    = isSigns ? "🌑 SIGNS" : "💀 ENCOUNTER";
    const chatOn   = isSigns ? clock.signsChat    : clock.encounterChat;
    const message  = isSigns ? clock.signsMessage : clock.encounterMessage;
    const tblName  = isSigns ? clock.signsTable   : clock.encounterTable;

    this._flash(type);

    if (chatOn && message?.trim()) {
      await ChatMessage.create({
        content: `
          <div class="doom-clock-chat-event doom-event-${type}">
            <div class="doom-event-header">
              <span class="doom-event-label">${label}</span>
              <span class="doom-event-clock-name">${clock.name}</span>
            </div>
            <div class="doom-event-body">${message}</div>
          </div>`,
        speaker: { alias: "Doom Clock" },
      });
    }

    if (tblName?.trim()) {
      const table = await resolveTable(tblName);
      if (table) {
        await table.draw({ displayChat: true });
      } else {
        ui.notifications.warn(`Doom Clock "${clock.name}": Roll Table "${tblName}" not found.`);
      }
    }
  },

  _flash(type) {
    let ov = document.getElementById("doom-clock-flash-overlay");
    if (!ov) {
      ov = document.createElement("div");
      ov.id = "doom-clock-flash-overlay";
      document.body.appendChild(ov);
    }
    ov.style.background = type === "encounter"
      ? "rgba(155, 25, 25, 0.65)"
      : "rgba(180, 130, 15, 0.50)";
    ov.style.transition = "none";
    ov.style.opacity    = "1";
    setTimeout(() => {
      ov.style.transition = "opacity 0.9s ease-out";
      ov.style.opacity    = "0";
    }, 350);
  },
};

// ──────────────────────────────────────────────────────
// SVG Clock Face
// ──────────────────────────────────────────────────────

function buildClockSVG(clock, size) {
  size = size ?? 110;
  const ns  = "http://www.w3.org/2000/svg";
  const cx  = size / 2, cy = size / 2;
  const r   = size / 2 - 5;
  const n   = clock.max;
  const gap = n > 2 ? 1.8 : 0;
  const span = (360 / n) - gap;

  const svg = document.createElementNS(ns, "svg");
  svg.setAttribute("width",   size);
  svg.setAttribute("height",  size);
  svg.setAttribute("viewBox", `0 0 ${size} ${size}`);
  svg.classList.add("doom-clock-svg");

  // decorative outer ring
  const outerRing = document.createElementNS(ns, "circle");
  outerRing.setAttribute("cx", cx); outerRing.setAttribute("cy", cy);
  outerRing.setAttribute("r", r + 3);
  outerRing.setAttribute("fill", "none");
  outerRing.setAttribute("stroke", "rgba(80,35,35,0.55)");
  outerRing.setAttribute("stroke-width", "1");
  svg.appendChild(outerRing);

  // background
  const bg = document.createElementNS(ns, "circle");
  bg.setAttribute("cx", cx); bg.setAttribute("cy", cy); bg.setAttribute("r", r);
  bg.setAttribute("fill", "rgba(8,4,4,0.78)");
  bg.setAttribute("stroke", "rgba(90,40,40,0.4)");
  bg.setAttribute("stroke-width", "1.5");
  svg.appendChild(bg);

  function polar(deg, rad) {
    const a = (deg * Math.PI) / 180;
    return { x: cx + rad * Math.cos(a), y: cy + rad * Math.sin(a) };
  }

  function arc(a1, a2, rad) {
    const s = polar(a1, rad), e = polar(a2, rad);
    return `M ${cx} ${cy} L ${s.x} ${s.y} A ${rad} ${rad} 0 ${a2-a1>180?1:0} 1 ${e.x} ${e.y} Z`;
  }

  const sigTop = clock.signsThresholdMax ?? 5;

  for (let i = 0; i < n; i++) {
    const a1 = -90 + i * (360 / n) + gap / 2;
    const a2 = a1 + span;

    // segment i=0 is the top (highest value), i=n-1 is the last segment (value=1)
    // segValue: which "remaining count" does this segment represent when filled?
    const segValue = n - i; // i=0 → segValue=n (full), i=n-1 → segValue=1 (last tick)
    const filled   = i < clock.value;

    const path = document.createElementNS(ns, "path");
    path.setAttribute("d", arc(a1, a2, r));
    path.setAttribute("stroke-width", "1");
    path.classList.add("doom-clock-segment");
    path.dataset.segment = i;

    if (filled) {
      path.classList.add(segValue <= sigTop ? "filled-danger" : "filled-safe");
    } else {
      path.classList.add("empty");
    }
    svg.appendChild(path);
  }

  // centre value text
  const txt = document.createElementNS(ns, "text");
  txt.setAttribute("x", cx); txt.setAttribute("y", cy);
  txt.classList.add("doom-clock-center-text");
  txt.textContent = String(clock.value);
  svg.appendChild(txt);

  // danger-zone threshold marker line
  const sigTop_pct = sigTop / n;
  if (sigTop > 0 && sigTop < n) {
    const markerAngle = -90 + (1 - sigTop_pct) * 360;
    const inner = polar(markerAngle, r - 10);
    const outer = polar(markerAngle, r);
    const tick  = document.createElementNS(ns, "line");
    tick.setAttribute("x1", inner.x); tick.setAttribute("y1", inner.y);
    tick.setAttribute("x2", outer.x); tick.setAttribute("y2", outer.y);
    tick.setAttribute("stroke",       "rgba(230,170,20,0.85)");
    tick.setAttribute("stroke-width", "2.5");
    svg.appendChild(tick);
  }

  return svg;
}

// ──────────────────────────────────────────────────────
// Edit Dialog  (ApplicationV2)
// ──────────────────────────────────────────────────────

class DoomClockEditDialog extends foundry.applications.api.ApplicationV2 {

  constructor(clock = null, opts = {}) {
    super(opts);
    this._clock = clock ? foundry.utils.deepClone(clock) : null;
    this._isNew = !clock;
  }

  static DEFAULT_OPTIONS = {
    id:       "doom-clock-edit-dialog",
    classes:  ["doom-clock-dialog"],
    tag:      "div",
    window:   { title: "Configure Doom Clock", resizable: true },
    position: { width: 520, height: "auto" },
  };

  get title() {
    return this._isNew ? "New Doom Clock" : `Edit — ${this._clock?.name}`;
  }

  async _renderHTML() {
    const c = this._clock ?? {
      name: "Encounter Clock", max: 20, dice: "d6",
      signsThresholdMax: 5,
      signsChat: true,    signsMessage: "⚠️ Something stirs… signs of danger.",    signsTable: "",
      encounterChat: true, encounterMessage: "💀 A random encounter occurs!", encounterTable: "",
    };

    const sel = (val, opt) => val === opt ? "selected" : "";
    const chk = (val)       => val ? "checked" : "";

    return `
<div class="dc-edit-wrap">

  <section class="dc-section">
    <h3 class="dc-section-title">⚙️ Clock Settings</h3>
    <div class="dc-grid-3">
      <div class="dc-field">
        <label>Name</label>
        <input name="name"  type="text"   value="${c.name}" placeholder="Encounter Clock" />
      </div>
      <div class="dc-field">
        <label>Max Segments</label>
        <input name="max"   type="number" value="${c.max}"  min="4" max="40" />
      </div>
      <div class="dc-field">
        <label>Dice to Roll</label>
        <select name="dice">
          <option value="d6"  ${sel(c.dice,"d6")} >d6</option>
          <option value="d8"  ${sel(c.dice,"d8")} >d8</option>
          <option value="d12" ${sel(c.dice,"d12")}>d12</option>
        </select>
      </div>
    </div>
    <div class="dc-field dc-field-check" style="margin-top:4px;">
      <label>
        <input name="playerControl" type="checkbox" ${chk(c.playerControl)} />
        Allow players to roll, tick &amp; reset this clock
      </label>
    </div>
  </section>

  <section class="dc-section dc-signs-section">
    <h3 class="dc-section-title">
      🌑 Signs Event
      <span class="dc-section-hint">Fires once when the clock first drops into the danger zone</span>
    </h3>
    <div class="dc-grid-2">
      <div class="dc-field">
        <label>Danger zone — value 1 through…</label>
        <input name="signsThresholdMax" type="number"
          value="${c.signsThresholdMax ?? 5}" min="1" max="20"
          title="Signs fires when the clock ticks into this range (1 – N)" />
      </div>
      <div class="dc-field dc-field-check">
        <label>
          <input name="signsChat" type="checkbox" ${chk(c.signsChat)} />
          Post message to Chat
        </label>
      </div>
    </div>
    <div class="dc-field">
      <label>Chat Message</label>
      <textarea name="signsMessage" rows="2">${c.signsMessage ?? ""}</textarea>
    </div>
    <div class="dc-field">
      <label>
        Roll Table
        <span class="dc-hint">Name or drag-drop a table here — leave blank to skip</span>
      </label>
      <input name="signsTable" type="text" value="${c.signsTable ?? ""}"
        placeholder="Table name  —or—  drag a Roll Table here" class="dc-table-drop" />
    </div>
  </section>

  <section class="dc-section dc-encounter-section">
    <h3 class="dc-section-title">
      💀 Encounter Event
      <span class="dc-section-hint">Fires when clock hits 0 — then auto-resets to max (${c.max})</span>
    </h3>
    <div class="dc-field dc-field-check">
      <label>
        <input name="encounterChat" type="checkbox" ${chk(c.encounterChat)} />
        Post message to Chat
      </label>
    </div>
    <div class="dc-field">
      <label>Chat Message</label>
      <textarea name="encounterMessage" rows="2">${c.encounterMessage ?? ""}</textarea>
    </div>
    <div class="dc-field">
      <label>
        Roll Table
        <span class="dc-hint">Name or drag-drop a table here — leave blank to skip</span>
      </label>
      <input name="encounterTable" type="text" value="${c.encounterTable ?? ""}"
        placeholder="Table name  —or—  drag a Roll Table here" class="dc-table-drop" />
    </div>
  </section>

  <div class="dc-buttons">
    <button type="button" id="dc-cancel">Cancel</button>
    <button type="button" id="dc-save" class="dc-save-btn">💾 Save Clock</button>
  </div>

</div>`;
  }

  _onRender(_ctx, _opts) {
    const html = this.element;
    html.querySelector("#dc-cancel")?.addEventListener("click", () => this.close());
    html.querySelector("#dc-save")  ?.addEventListener("click", () => this._save(html));

    // Drag-drop Roll Table onto inputs
    html.querySelectorAll(".dc-table-drop").forEach(input => {
      input.addEventListener("dragover", e => { e.preventDefault(); e.dataTransfer.dropEffect = "copy"; });
      input.addEventListener("drop", e => {
        e.preventDefault();
        try {
          const data = JSON.parse(e.dataTransfer.getData("text/plain"));
          if (data?.type === "RollTable" && data?.uuid) input.value = data.uuid;
        } catch (_) {}
      });
    });
  }

  async _save(html) {
    const v = name => html.querySelector(`[name="${name}"]`)?.value ?? "";
    const b = name => html.querySelector(`[name="${name}"]`)?.checked ?? false;
    const n = (name, def) => Number(v(name)) || def;

    const data = {
      name:              v("name").trim() || "Encounter Clock",
      max:               n("max", 20),
      dice:              v("dice"),
      playerControl:     b("playerControl"),
      signsThresholdMax: n("signsThresholdMax", 5),
      signsChat:         b("signsChat"),
      signsMessage:      v("signsMessage"),
      signsTable:        v("signsTable").trim(),
      encounterChat:     b("encounterChat"),
      encounterMessage:  v("encounterMessage"),
      encounterTable:    v("encounterTable").trim(),
    };

    if (this._isNew) {
      await ClockDB.add(data);
    } else {
      const ratio  = data.max / this._clock.max;
      const newVal = clamp(Math.round(this._clock.value * ratio), 0, data.max);
      await ClockDB.update(this._clock.id, {
        ...data,
        value:         newVal,
        signsHasFired: false,
      });
    }

    await this.close();
    DoomClockPanel.instance?.render();
  }

  _replaceHTML(result, content) { content.innerHTML = result; }
}

// ──────────────────────────────────────────────────────
// Widget factory
// ──────────────────────────────────────────────────────

function buildWidget(clock, panel) {
  const size      = clock.size ?? 110;
  const sigTop    = clock.signsThresholdMax ?? 5;
  const inDanger  = clock.value > 0 && clock.value <= sigTop;
  const exhausted = clock.value <= 0;

  const widget = document.createElement("div");
  widget.classList.add("doom-clock-widget");
  widget.dataset.clockId = clock.id;
  if (exhausted) widget.classList.add("clock-exhausted");
  else if (inDanger) widget.classList.add("clock-danger");
  if (clock.playerControl) widget.classList.add("player-open");

  if (clock.position) {
    widget.style.cssText = `position:fixed;left:${clock.position.x}px;top:${clock.position.y}px;z-index:75;`;
  }

  // ── Name label
  const label = document.createElement("div");
  label.classList.add("doom-clock-label");
  label.textContent = clock.name;
  widget.appendChild(label);

  // ── Zone status badge
  const zone = document.createElement("div");
  zone.classList.add("doom-clock-zone",
    exhausted ? "zone-encounter" : inDanger ? "zone-signs" : "zone-safe");
  zone.textContent = exhausted ? "💀 ENCOUNTER" : inDanger ? "🌑 SIGNS" : "🟢 Safe";
  widget.appendChild(zone);

  // ── Player-open badge (visible to players when they have control)
  if (!isGM() && clock.playerControl) {
    const badge = document.createElement("div");
    badge.classList.add("doom-clock-player-badge");
    badge.textContent = "🎲 Your turn to roll";
    widget.appendChild(badge);
  }

  // ── SVG clock face
  const svgWrap = document.createElement("div");
  svgWrap.classList.add("doom-clock-svg-wrap");
  const svg = buildClockSVG(clock, size);

  if (canControl(clock)) {
    svg.querySelectorAll(".doom-clock-segment").forEach(seg => {
      seg.addEventListener("click", async e => {
        e.stopPropagation();
        // Clicking segment i sets clock to (max - i) — clicking top segment = full, bottom = 1
        const i      = Number(seg.dataset.segment);
        const newVal = clamp(clock.max - i, 0, clock.max);
        const prev   = clock.value;
        await ClockDB.update(clock.id, { value: newVal });
        const updated = ClockDB.getById(clock.id);
        if (updated) await EventEngine.evaluate(updated, prev);
        panel.render();
      });
    });
  }

  svgWrap.appendChild(svg);
  widget.appendChild(svgWrap);

  // ── Controls row (players if enabled, always GM)
  if (canControl(clock)) {
    const ctrl = document.createElement("div");
    ctrl.classList.add("doom-clock-controls");

    // Tick down −1
    ctrl.appendChild(mkBtn("−", "Tick down (−1)", async () => {
      const prev   = clock.value;
      const newVal = clamp(prev - 1, 0, clock.max);
      await ClockDB.update(clock.id, { value: newVal });
      const updated = ClockDB.getById(clock.id);
      if (updated) await EventEngine.evaluate(updated, prev);
      panel.render();
    }));

    // 🎲 Roll & Tick
    const rb = mkBtn(`🎲 ${clock.dice}`, `Roll ${clock.dice} and tick down`, async () => {
      await rollAndTick(clock, panel);
    });
    rb.classList.add("roll-btn");
    ctrl.appendChild(rb);

    // Tick up +1 (restore)
    ctrl.appendChild(mkBtn("+", "Tick up (+1)", async () => {
      await ClockDB.update(clock.id, { value: clamp(clock.value + 1, 0, clock.max) });
      panel.render();
    }));

    // Reset ↺
    ctrl.appendChild(mkBtn("↺", "Reset clock to max", async () => {
      await ClockDB.update(clock.id, { value: clock.max, signsHasFired: false });
      panel.render();
    }));

    // ── GM-only: Edit, Delete, Resize, Drag
    if (isGM()) {
      ctrl.appendChild(mkBtn(
        `<i class="fas fa-cog" style="font-size:9px"></i>`, "Edit clock",
        () => new DoomClockEditDialog(clock).render(true)
      ));

      const del = mkBtn(
        `<i class="fas fa-trash" style="font-size:9px"></i>`, "Delete clock",
        async () => {
          const ok = await foundry.applications.api.DialogV2.confirm({
            window:  { title: "Delete Clock" },
            content: `<p>Delete <strong>${clock.name}</strong>?</p>`,
          });
          if (ok) { await ClockDB.remove(clock.id); panel.render(); }
        }
      );
      del.classList.add("del-btn");
      ctrl.appendChild(del);
    }

    widget.appendChild(ctrl);

    // Resize + drag — GM only
    if (isGM()) {
      const rh = document.createElement("div");
      rh.classList.add("doom-clock-resize-handle");
      rh.title     = "Drag to resize";
      rh.innerHTML = "⤡";
      attachResize(rh, widget, clock, panel);
      widget.appendChild(rh);

      attachDrag(widget, clock, panel);
    }
  }

  return widget;
}

// ── helpers ──

function mkBtn(html, title, onClick) {
  const b = document.createElement("button");
  b.classList.add("doom-clock-btn");
  b.title = title; b.innerHTML = html;
  b.addEventListener("click", onClick);
  return b;
}

async function rollAndTick(clock, panel) {
  const faces  = { d6: 6, d8: 8, d12: 12 };
  const roll   = new Roll(`1d${faces[clock.dice] ?? 6}`);
  await roll.evaluate();

  const result = roll.total;
  const prev   = clock.value;
  const newVal = clamp(prev - result, 0, clock.max);

  await roll.toMessage({
    flavor: `<div class="doom-clock-roll-flavor">
      <strong>${clock.name}</strong> — rolled <strong>${clock.dice}</strong>
      → <strong>${result}</strong>
      &nbsp;|&nbsp; Clock: <strong>${newVal}&thinsp;/&thinsp;${clock.max}</strong>
    </div>`,
    speaker: ChatMessage.getSpeaker({ alias: "Doom Clock" }),
  });

  await ClockDB.update(clock.id, { value: newVal });
  const updated = ClockDB.getById(clock.id);
  if (updated) await EventEngine.evaluate(updated, prev);
  panel.render();
}

function attachDrag(widget, clock, panel) {
  widget.addEventListener("mousedown", e => {
    if (e.button !== 0 || e.target.closest("button,.doom-clock-segment,.doom-clock-resize-handle")) return;
    const rect = widget.getBoundingClientRect();
    const ox = rect.left, oy = rect.top, sx = e.clientX, sy = e.clientY;
    widget.style.cssText = `position:fixed;left:${ox}px;top:${oy}px;z-index:80;`;
    widget.classList.add("dragging");
    if (widget.parentElement?.id === "doom-clock-panel") document.body.appendChild(widget);
    const mv = me => {
      widget.style.left = (ox + me.clientX - sx) + "px";
      widget.style.top  = (oy + me.clientY - sy) + "px";
    };
    const up = async () => {
      widget.classList.remove("dragging");
      document.removeEventListener("mousemove", mv);
      document.removeEventListener("mouseup", up);
      await ClockDB.update(clock.id, {
        position: { x: parseFloat(widget.style.left), y: parseFloat(widget.style.top) }
      });
    };
    document.addEventListener("mousemove", mv);
    document.addEventListener("mouseup", up);
  });
}

function attachResize(handle, widget, clock, panel) {
  handle.addEventListener("mousedown", e => {
    e.stopPropagation(); e.preventDefault();
    const sx = e.clientX, s0 = clock.size ?? 110;
    const mv = me => {
      const sz  = clamp(s0 + (me.clientX - sx), 60, 220);
      const svg = widget.querySelector(".doom-clock-svg");
      if (svg) { svg.setAttribute("width", sz); svg.setAttribute("height", sz); svg.setAttribute("viewBox", `0 0 ${sz} ${sz}`); }
    };
    const up = async me => {
      document.removeEventListener("mousemove", mv);
      document.removeEventListener("mouseup", up);
      await ClockDB.update(clock.id, { size: clamp(s0 + (me.clientX - sx), 60, 220) });
      panel.render();
    };
    document.addEventListener("mousemove", mv);
    document.addEventListener("mouseup", up);
  });
}

// ──────────────────────────────────────────────────────
// Panel
// ──────────────────────────────────────────────────────

class DoomClockPanel {

  static instance = null;

  constructor() {
    DoomClockPanel.instance = this;
    this._sidebarObs = null;
    this._resizeObs  = null;
  }

  render() {
    document.getElementById("doom-clock-panel")?.remove();

    const panel = document.createElement("div");
    panel.id = "doom-clock-panel";
    document.body.appendChild(panel);

    for (const clock of ClockDB.getAll()) panel.appendChild(buildWidget(clock, this));

    if (isGM()) {
      const addBtn = document.createElement("button");
      addBtn.id        = "doom-clock-add-btn";
      addBtn.title     = "Add Doom Clock";
      addBtn.innerHTML = `<i class="fas fa-plus"></i>`;
      addBtn.addEventListener("click", () => new DoomClockEditDialog(null).render(true));
      panel.appendChild(addBtn);
    }

    this._watchSidebar(panel);
  }

  _watchSidebar(panel) {
    const sb = document.getElementById("sidebar");
    if (!sb) return;
    const adjust = () => {
      const w = sb.classList.contains("collapsed") ? 32 : (sb.offsetWidth || 300);
      panel.style.right = (w + 12) + "px";
    };
    adjust();
    if (!this._sidebarObs) {
      this._sidebarObs = new MutationObserver(adjust);
      this._sidebarObs.observe(sb, { attributes: true, attributeFilter: ["class"] });
    }
    if (!this._resizeObs) {
      this._resizeObs = new ResizeObserver(adjust);
      this._resizeObs.observe(sb);
    }
  }
}

// ──────────────────────────────────────────────────────
// Bootstrap
// ──────────────────────────────────────────────────────

Hooks.once("ready", () => {
  new DoomClockPanel().render();

  Hooks.on("collapseSidebar", () => {
    const p = document.getElementById("doom-clock-panel");
    if (p) DoomClockPanel.instance?._watchSidebar(p);
  });

  // Public API for macros / console
  window.doomClockDB    = ClockDB;
  window.doomClockPanel = DoomClockPanel;
});
